package pl.michalzadrozny.simplecrudapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsWeek4Application {

    public static void main(String[] args) {
        SpringApplication.run(AsWeek4Application.class, args);
    }

}
